package com.co.bonbonite.userinterfaces;

import net.serenitybdd.screenplay.targets.Target;

public class HomePage {

    public static final Target BTN_REGISTER = Target.the("Enter the identification").locatedBy("//div[@class='myaccount']//a");



}
