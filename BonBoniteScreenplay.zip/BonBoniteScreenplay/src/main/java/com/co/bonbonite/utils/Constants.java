package com.co.bonbonite.utils;

public class Constants {
    public static final String URL = "https://www.bon-bonite.com";
}
